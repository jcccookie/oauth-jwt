const BOAT = 'Boat';

module.exports = {
  BOAT
}