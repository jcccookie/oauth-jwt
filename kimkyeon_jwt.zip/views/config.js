export const CLIENT = {
  CLIENT_ID: "482973555999-g8uv84snuh6s68s004pc1ngi9ldbg913.apps.googleusercontent.com",
  CLIENT_SECRET: "ka8u4P_qc45ldQ6oQLxtXzLm",
}

export const OAUTH_PROVIDER = "https://accounts.google.com/o/oauth2/v2/auth";

// export const REDIRECT_URL = "http://localhost:8080";
export const REDIRECT_URL = "https://oauth-jwt-314004.uc.r.appspot.com";

export const GOOGLE_APIS = "https://www.googleapis.com/oauth2/v4/token";

export const GOOGLE_PEOPLE = "https://people.googleapis.com/v1/people/me?personFields=names";